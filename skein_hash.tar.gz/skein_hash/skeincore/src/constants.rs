/***************************************************************************************************
** MODULE NAME:    constants
**
** PURPOSE:        the variables that should stay the same through the library
**
** PUBLIC CONSTS:  (see all below)
**
** PUBLIC TYPES:   (none)
**
** PUBLIC FUNCS:   (none)
**
** NOTES:          (none)
***************************************************************************************************/
//Data constants
pub const BYTES_PER_WORD : usize = 8;

//tweak constants
pub const TWEAK_WORDS : usize = 3;
pub const TWEAK_TYPE_KEY : u8 = 0;
pub const TWEAK_TYPE_CONFIGURATION : u8  = 4;
pub const TWEAK_TYPE_PERSONALIZATION : u8  = 8;
pub const TWEAK_TYPE_PUBLIC_KEY : u8  = 12;
pub const TWEAK_TYPE_KEY_IDENTIFIER : u8  = 16;
pub const TWEAK_TYPE_NONCE : u8  = 20;
pub const TWEAK_TYPE_MESSAGE : u8  = 48;
pub const TWEAK_TYPE_OUTPUT : u8  = 63;
