/***************************************************************************************************
** MODULE NAME:    typedefs
**
** PURPOSE:        list of structures used in this library
**
** PUBLIC CONSTS:  (none)
**
** PUBLIC TYPES:   (see below)
**
** PUBLIC FUNCS:   (none)
**
** NOTES:          (none)
***************************************************************************************************/

/***************************************************************************************************
** STRUCT NAME:      UbiChainBlock
**
** PURPOSE:          groups together all the data structures used for ubi chaining
**
** PUBLIC VARIABLES: block_bit_len, chain_block, key_instance, tweak, message_operating_copy,
**                   message_final_add_copy, message_buffer, message_buffer_index
**
** PUBLIC FUNCTIONS: new
**
** NOTES:            (none)
***************************************************************************************************/
pub struct UbiChainBlock0256 {

    pub chain_block : [u64;5], //the chain block also acts as the key in threefish
    pub tweak : [u64;3], //a weird modifier variable thingy
    pub message_operating_copy : [u64;4], //this is the copy of the message that gets operated on
    pub message_final_add_copy : [u64;4] //this is the copy of the message that gets added at the end
}

impl UbiChainBlock0256 {
/***************************************************************************************************
** FUNCTION NAME:  new
**
** PURPOSE:        (constructor)
**
** ARGUMENTS:      block_bit_size = the size of the block in bits
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
    pub fn new () -> UbiChainBlock0256 {
        UbiChainBlock0256 {
            chain_block : [0;5],
            tweak : [0;3],
            message_operating_copy : [0;4],
            message_final_add_copy : [0;4],
        }
    }
}
/***************************************************************************************************
** STRUCT NAME:      UbiChainBlock
**
** PURPOSE:          groups together all the data structures used for ubi chaining
**
** PUBLIC VARIABLES: block_bit_len, chain_block, key_instance, tweak, message_operating_copy,
**                   message_final_add_copy, message_buffer, message_buffer_index
**2
** PUBLIC FUNCTIONS: new
**
** NOTES:            (none)
***************************************************************************************************/
pub struct UbiChainBlock0512 {

    pub chain_block : [u64;9], //the chain block also acts as the key in threefish
    pub tweak : [u64;3], //a weird modifier variable thingy
    pub message_operating_copy : [u64;8], //this is the copy of the message that gets operated on
    pub message_final_add_copy : [u64;8] //this is the copy of the message that gets added at the end
}

impl UbiChainBlock0512 {
/***************************************************************************************************
** FUNCTION NAME:  new
**
** PURPOSE:        (constructor)
**
** ARGUMENTS:      block_bit_size = the size of the block in bits
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
    pub fn new () -> UbiChainBlock0512 {
        UbiChainBlock0512 {
            chain_block : [0;9],
            tweak : [0;3],
            message_operating_copy : [0;8],
            message_final_add_copy : [0;8],
        }
    }
}
/***************************************************************************************************
** STRUCT NAME:      UbiChainBlock
**
** PURPOSE:          groups together all the data structures used for ubi chaining
**
** PUBLIC VARIABLES: block_bit_len, chain_block, key_instance, tweak, message_operating_copy,
**                   message_final_add_copy, message_buffer, message_buffer_index
**
** PUBLIC FUNCTIONS: new
**
** NOTES:            (none)
***************************************************************************************************/
pub struct UbiChainBlock1024 {

    pub chain_block : [u64;17], //the chain block also acts as the key in threefish
    pub tweak : [u64;3], //a weird modifier variable thingy
    pub message_operating_copy : [u64;16], //this is the copy of the message that gets operated on
    pub message_final_add_copy : [u64;16] //this is the copy of the message that gets added at the end
}

impl UbiChainBlock1024 {
/***************************************************************************************************
** FUNCTION NAME:  new
**
** PURPOSE:        (constructor)
**
** ARGUMENTS:      block_bit_size = the size of the block in bits
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
    pub fn new () -> UbiChainBlock1024 {
        UbiChainBlock1024 {
            chain_block : [0;17],
            tweak : [0;3],
            message_operating_copy : [0;16],
            message_final_add_copy : [0;16],
        }
    }
}
