/***************************************************************************************************
** MODULE NAME:    constants
**
** PURPOSE:        the variables that should stay the same through the library
**
** PUBLIC CONSTS:  (see all below)
**
** PUBLIC TYPES:   (none)
**
** PUBLIC FUNCS:   (none)
**
** NOTES:          (none)
***************************************************************************************************/

//Key Expansion Definitions
pub const C_240 : u64= 0x1BD11BDAA9FC1A22;


pub const WORD_COUNT_0256 : usize = 4;
pub const WORD_COUNT_0512 : usize = 8;
pub const WORD_COUNT_1024 : usize = 16;

pub const ROUNDS_0256 :usize = 9;
pub const ROUNDS_0512 :usize = 9;
pub const ROUNDS_1024 :usize = 10;

//Rotation Constants
pub const ROTATE_CONSTANTS_0256_0_0 : usize = 14;
pub const ROTATE_CONSTANTS_0256_0_1 : usize = 16;
pub const ROTATE_CONSTANTS_0256_1_0 : usize = 52;
pub const ROTATE_CONSTANTS_0256_1_1 : usize = 57;
pub const ROTATE_CONSTANTS_0256_2_0 : usize = 23;
pub const ROTATE_CONSTANTS_0256_2_1 : usize = 40;
pub const ROTATE_CONSTANTS_0256_3_0 : usize = 5;
pub const ROTATE_CONSTANTS_0256_3_1 : usize = 37;
pub const ROTATE_CONSTANTS_0256_4_0 : usize = 25;
pub const ROTATE_CONSTANTS_0256_4_1 : usize = 33;
pub const ROTATE_CONSTANTS_0256_5_0 : usize = 46;
pub const ROTATE_CONSTANTS_0256_5_1 : usize = 12;
pub const ROTATE_CONSTANTS_0256_6_0 : usize = 58;
pub const ROTATE_CONSTANTS_0256_6_1 : usize = 22;
pub const ROTATE_CONSTANTS_0256_7_0 : usize = 32;
pub const ROTATE_CONSTANTS_0256_7_1 : usize = 32;
pub const ROTATE_CONSTANTS_0512_0_0 : usize = 46;
pub const ROTATE_CONSTANTS_0512_0_1 : usize = 36;
pub const ROTATE_CONSTANTS_0512_0_2 : usize = 19;
pub const ROTATE_CONSTANTS_0512_0_3 : usize = 37;
pub const ROTATE_CONSTANTS_0512_1_0 : usize = 33;
pub const ROTATE_CONSTANTS_0512_1_1 : usize = 27;
pub const ROTATE_CONSTANTS_0512_1_2 : usize = 14;
pub const ROTATE_CONSTANTS_0512_1_3 : usize = 42;
pub const ROTATE_CONSTANTS_0512_2_0 : usize = 17;
pub const ROTATE_CONSTANTS_0512_2_1 : usize = 49;
pub const ROTATE_CONSTANTS_0512_2_2 : usize = 36;
pub const ROTATE_CONSTANTS_0512_2_3 : usize = 39;
pub const ROTATE_CONSTANTS_0512_3_0 : usize = 44;
pub const ROTATE_CONSTANTS_0512_3_1 : usize = 9;
pub const ROTATE_CONSTANTS_0512_3_2 : usize = 54;
pub const ROTATE_CONSTANTS_0512_3_3 : usize = 56;
pub const ROTATE_CONSTANTS_0512_4_0 : usize = 39;
pub const ROTATE_CONSTANTS_0512_4_1 : usize = 30;
pub const ROTATE_CONSTANTS_0512_4_2 : usize = 34;
pub const ROTATE_CONSTANTS_0512_4_3 : usize = 24;
pub const ROTATE_CONSTANTS_0512_5_0 : usize = 13;
pub const ROTATE_CONSTANTS_0512_5_1 : usize = 50;
pub const ROTATE_CONSTANTS_0512_5_2 : usize = 10;
pub const ROTATE_CONSTANTS_0512_5_3 : usize = 17;
pub const ROTATE_CONSTANTS_0512_6_0 : usize = 25;
pub const ROTATE_CONSTANTS_0512_6_1 : usize = 29;
pub const ROTATE_CONSTANTS_0512_6_2 : usize = 39;
pub const ROTATE_CONSTANTS_0512_6_3 : usize = 43;
pub const ROTATE_CONSTANTS_0512_7_0 : usize = 8;
pub const ROTATE_CONSTANTS_0512_7_1 : usize = 35;
pub const ROTATE_CONSTANTS_0512_7_2 : usize = 56;
pub const ROTATE_CONSTANTS_0512_7_3 : usize = 22;

pub const ROTATE_CONSTANTS_1024_0_0 : usize = 24;
pub const ROTATE_CONSTANTS_1024_0_1 : usize = 13;
pub const ROTATE_CONSTANTS_1024_0_2 : usize = 8;
pub const ROTATE_CONSTANTS_1024_0_3 : usize = 47;
pub const ROTATE_CONSTANTS_1024_0_4 : usize = 8;
pub const ROTATE_CONSTANTS_1024_0_5 : usize = 17;
pub const ROTATE_CONSTANTS_1024_0_6 : usize = 22;
pub const ROTATE_CONSTANTS_1024_0_7 : usize = 37;
pub const ROTATE_CONSTANTS_1024_1_0 : usize = 38;
pub const ROTATE_CONSTANTS_1024_1_1 : usize = 19;
pub const ROTATE_CONSTANTS_1024_1_2 : usize = 10;
pub const ROTATE_CONSTANTS_1024_1_3 : usize = 55;
pub const ROTATE_CONSTANTS_1024_1_4 : usize = 49;
pub const ROTATE_CONSTANTS_1024_1_5 : usize = 18;
pub const ROTATE_CONSTANTS_1024_1_6 : usize = 23;
pub const ROTATE_CONSTANTS_1024_1_7 : usize = 52;
pub const ROTATE_CONSTANTS_1024_2_0 : usize = 33;
pub const ROTATE_CONSTANTS_1024_2_1 : usize = 4;
pub const ROTATE_CONSTANTS_1024_2_2 : usize = 51;
pub const ROTATE_CONSTANTS_1024_2_3 : usize = 13;
pub const ROTATE_CONSTANTS_1024_2_4 : usize = 34;
pub const ROTATE_CONSTANTS_1024_2_5 : usize = 41;
pub const ROTATE_CONSTANTS_1024_2_6 : usize = 59;
pub const ROTATE_CONSTANTS_1024_2_7 : usize = 17;
pub const ROTATE_CONSTANTS_1024_3_0 : usize = 5;
pub const ROTATE_CONSTANTS_1024_3_1 : usize = 20;
pub const ROTATE_CONSTANTS_1024_3_2 : usize = 48;
pub const ROTATE_CONSTANTS_1024_3_3 : usize = 41;
pub const ROTATE_CONSTANTS_1024_3_4 : usize = 47;
pub const ROTATE_CONSTANTS_1024_3_5 : usize = 28;
pub const ROTATE_CONSTANTS_1024_3_6 : usize = 16;
pub const ROTATE_CONSTANTS_1024_3_7 : usize = 25;
pub const ROTATE_CONSTANTS_1024_4_0 : usize = 41;
pub const ROTATE_CONSTANTS_1024_4_1 : usize = 9;
pub const ROTATE_CONSTANTS_1024_4_2 : usize = 37;
pub const ROTATE_CONSTANTS_1024_4_3 : usize = 31;
pub const ROTATE_CONSTANTS_1024_4_4 : usize = 12;
pub const ROTATE_CONSTANTS_1024_4_5 : usize = 47;
pub const ROTATE_CONSTANTS_1024_4_6 : usize = 44;
pub const ROTATE_CONSTANTS_1024_4_7 : usize = 30;
pub const ROTATE_CONSTANTS_1024_5_0 : usize = 16;
pub const ROTATE_CONSTANTS_1024_5_1 : usize = 34;
pub const ROTATE_CONSTANTS_1024_5_2 : usize = 56;
pub const ROTATE_CONSTANTS_1024_5_3 : usize = 51;
pub const ROTATE_CONSTANTS_1024_5_4 : usize = 4;
pub const ROTATE_CONSTANTS_1024_5_5 : usize = 53;
pub const ROTATE_CONSTANTS_1024_5_6 : usize = 42;
pub const ROTATE_CONSTANTS_1024_5_7 : usize = 41;
pub const ROTATE_CONSTANTS_1024_6_0 : usize = 31;
pub const ROTATE_CONSTANTS_1024_6_1 : usize = 44;
pub const ROTATE_CONSTANTS_1024_6_2 : usize = 47;
pub const ROTATE_CONSTANTS_1024_6_3 : usize = 46;
pub const ROTATE_CONSTANTS_1024_6_4 : usize = 19;
pub const ROTATE_CONSTANTS_1024_6_5 : usize = 42;
pub const ROTATE_CONSTANTS_1024_6_6 : usize = 44;
pub const ROTATE_CONSTANTS_1024_6_7 : usize = 25;
pub const ROTATE_CONSTANTS_1024_7_0 : usize = 9;
pub const ROTATE_CONSTANTS_1024_7_1 : usize = 48;
pub const ROTATE_CONSTANTS_1024_7_2 : usize = 35;
pub const ROTATE_CONSTANTS_1024_7_3 : usize = 52;
pub const ROTATE_CONSTANTS_1024_7_4 : usize = 23;
pub const ROTATE_CONSTANTS_1024_7_5 : usize = 31;
pub const ROTATE_CONSTANTS_1024_7_6 : usize = 37;
pub const ROTATE_CONSTANTS_1024_7_7 : usize = 20;
