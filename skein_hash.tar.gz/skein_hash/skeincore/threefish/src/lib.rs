/***************************************************************************************************
** LIBRARY NAME:   threefish
**
** PURPOSE:        this is the module that encrypts and decrypts blocks using the threefish algo
**
** PUBLIC CONSTS:  (see module constants)
**
** PUBLIC TYPES:   (see module typedefs)
**
** PUBLIC FUNCS:   encrypt_block -> void, decrypt_block -> void
**
** NOTES:          (none)
***************************************************************************************************/

mod constants;
mod modulo_2_64;

/***************************************************************************************************
** FUNCTION NAME:  rotate_64_left
**
** PURPOSE:        rotates a 64 bit entity to the left by a specified number
**
** ARGUMENTS:      word = the 64 bit entity to rotate
**                 N = the number of bits to shift by
**
** RETURN:         a 64 bit entity that has been rotated
**
** NOTES:          (none)
***************************************************************************************************/
#[inline]
fn rotate_64_left(word : u64, n : usize) -> u64{
    return (word << n) | (word >> (64-n));
}

/***************************************************************************************************
** FUNCTION NAME:  rotate_64_right
**
** PURPOSE:        rotates a 64 bit entity to the right by a specified number
**
** ARGUMENTS:      word = the 64 bit entity to rotate
**                 N = the number of bits to shift by
**
** RETURN:         a 64 bit entity that has been rotated
**
** NOTES:          (none)
***************************************************************************************************/
#[inline]
fn rotate_64_right(word : u64, n : usize) -> u64{
    return (word >> n) | (word << (64-n));
}

/***************************************************************************************************
** FUNCTION NAME:  encrypt_block_0256
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn encrypt_block_0256(state : &mut [u64;4], key : &mut [u64;5], tweak : & [u64;3]){

//get parity
    key[constants::WORD_COUNT_0256] = constants::C_240;
    for i in 0..constants::WORD_COUNT_0256{
        key[constants::WORD_COUNT_0256] ^= key[i];
    }

//first key injection
    for i in 0..constants::WORD_COUNT_0256 {
        state[i] = modulo_2_64::add(state[i],key[(i)%(constants::WORD_COUNT_0256+1)]);
    }
    state[constants::WORD_COUNT_0256-3] = modulo_2_64::add(state[constants::WORD_COUNT_0256-3],
    tweak[0]);
    state[constants::WORD_COUNT_0256-2] = modulo_2_64::add(state[constants::WORD_COUNT_0256-2],
    tweak[1]);

//process rounds
    for r in 0..constants::ROUNDS_0256{

        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_0_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_0_1);
        state[3] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_1_0);
        state[3] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_1_1);
        state[1] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_2_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_2_1);
        state[3] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_3_0);
        state[3] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_3_1);
        state[1] ^= state[2];
     //key Injection 0
        for i in 0..constants::WORD_COUNT_0256 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_0256+1)]);
        }
        state[constants::WORD_COUNT_0256-3] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        3],tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_0256-2] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        2],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0256-1] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        1],(2*r+1) as u64);

        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_4_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_4_1);
        state[3] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_5_0);
        state[3] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_5_1);
        state[1] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_6_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_6_1);
        state[3] ^= state[2];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0256_7_0);
        state[3] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0256_7_1);
        state[1] ^= state[2];

        for i in 0..constants::WORD_COUNT_0256 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_0256+1)]);
        }
        state[constants::WORD_COUNT_0256-3] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        3],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0256-2] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        2],tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_0256-1] = modulo_2_64::add(state[constants::WORD_COUNT_0256-
        1],(2*r+2) as u64);

    }
}

/***************************************************************************************************
** FUNCTION NAME:  decrypt_block_0256
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn decrypt_block_0256(state : &mut [u64;4], key : &mut [u64;5], tweak : & [u64;3]){

//get parity
    key[constants::WORD_COUNT_0256] = constants::C_240;
    for i in 0..constants::WORD_COUNT_0256{
        key[constants::WORD_COUNT_0256] ^= key[i];
    }


//process rounds
    for r in (0..constants::ROUNDS_0256).rev(){

        for i in 0..constants::WORD_COUNT_0256 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_0256+1)]);
        }
        state[constants::WORD_COUNT_0256-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        3],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0256-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        2],tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_0256-1] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        1],(2*r+2) as u64);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_7_0);
        state[0] =  modulo_2_64::minus(state[0],state[3]);

        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_7_1);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_6_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_6_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_5_0);
        state[0] =  modulo_2_64::minus(state[0],state[3]);

        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_5_1);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_4_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_4_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        for i in 0..constants::WORD_COUNT_0256 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_0256+1)]);
        }
        state[constants::WORD_COUNT_0256-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        3],tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_0256-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        2],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0256-1] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-
        1],(2*r+1) as u64);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_3_0);
        state[0] =  modulo_2_64::minus(state[0],state[3]);

        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_3_1);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_2_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_2_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_1_0);
        state[0] =  modulo_2_64::minus(state[0],state[3]);

        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_1_1);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0256_0_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0256_0_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);
    }
    for i in 0..constants::WORD_COUNT_0256 {
        state[i] = modulo_2_64::minus(state[i],key[(i)%(constants::WORD_COUNT_0256+1)]);
    }
    state[constants::WORD_COUNT_0256-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-3],
    tweak[0]);
    state[constants::WORD_COUNT_0256-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0256-2],
    tweak[1]);

}

/***************************************************************************************************
** FUNCTION NAME:  encrypt_block_0512
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn encrypt_block_0512(state : &mut [u64;8], key : &mut [u64;9], tweak : &
[u64;3]){

//get parity
    key[constants::WORD_COUNT_0512] = constants::C_240;
    for i in 0..constants::WORD_COUNT_0512{
        key[constants::WORD_COUNT_0512] ^= key[i];
    }

//first key injection
    for i in 0..constants::WORD_COUNT_0512 {
        state[i] = modulo_2_64::add(state[i],key[(i)%(constants::WORD_COUNT_0512+1)]);
    }
    state[constants::WORD_COUNT_0512-3] = modulo_2_64::add(state[constants::WORD_COUNT_0512-3],
    tweak[0]);
    state[constants::WORD_COUNT_0512-2] = modulo_2_64::add(state[constants::WORD_COUNT_0512-2],
    tweak[1]);


//process rounds
    for r in 0..constants::ROUNDS_0512{


        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_0_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_0_1);
        state[3] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_0_2);
        state[5] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_0_3);
        state[7] ^= state[6];


        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_1_0);
        state[1] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_1_1);
        state[7] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_1_2);
        state[5] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_1_3);
        state[3] ^= state[0];


        state[4] =  modulo_2_64::add(state[4],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_2_0);
        state[1] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_2_1);
        state[3] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_2_2);
        state[5] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_2_3);
        state[7] ^= state[2];


        state[6] =  modulo_2_64::add(state[6],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_3_0);
        state[1] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_3_1);
        state[7] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_3_2);
        state[5] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_3_3);
        state[3] ^= state[4];

        for i in 0..constants::WORD_COUNT_0512 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_0512+1)]);
        }
        state[constants::WORD_COUNT_0512-3] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        3],tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_0512-2] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        2],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0512-1] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        1],(2*r+1) as u64);


        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_4_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_4_1);
        state[3] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_4_2);
        state[5] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_4_3);
        state[7] ^= state[6];


        state[2] =  modulo_2_64::add(state[2],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_5_0);
        state[1] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_5_1);
        state[7] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_5_2);
        state[5] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_5_3);
        state[3] ^= state[0];


        state[4] =  modulo_2_64::add(state[4],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_6_0);
        state[1] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_6_1);
        state[3] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_6_2);
        state[5] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_6_3);
        state[7] ^= state[2];


        state[6] =  modulo_2_64::add(state[6],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_0512_7_0);
        state[1] ^= state[6];

        state[0] =  modulo_2_64::add(state[0],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_0512_7_1);
        state[7] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_0512_7_2);
        state[5] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_0512_7_3);
        state[3] ^= state[4];

        for i in 0..constants::WORD_COUNT_0512 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_0512+1)]);
        }
        state[constants::WORD_COUNT_0512-3] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        3],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0512-2] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        2],tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_0512-1] = modulo_2_64::add(state[constants::WORD_COUNT_0512-
        1],(2*r+2) as u64);
    }
}

/***************************************************************************************************
** FUNCTION NAME:  decrypt_block_0512
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn decrypt_block_0512(state : &mut [u64;8], key : &mut [u64;9], tweak : &
[u64;3]){

//get parity
    key[constants::WORD_COUNT_0512] = constants::C_240;
    for i in 0..constants::WORD_COUNT_0512{
        key[constants::WORD_COUNT_0512] ^= key[i];
    }

//process rounds
    for r in (0..constants::ROUNDS_0512).rev(){

        for i in 0..constants::WORD_COUNT_0512 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_0512+1)]);
        }
        state[constants::WORD_COUNT_0512-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        3],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0512-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        2],tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_0512-1] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        1],(2*r+2) as u64);


        state[1] ^= state[6];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_7_0);
        state[6] =  modulo_2_64::minus(state[6],state[1]);

        state[7] ^= state[0];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_7_1);
        state[0] =  modulo_2_64::minus(state[0],state[7]);

        state[5] ^= state[2];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_7_2);
        state[2] =  modulo_2_64::minus(state[2],state[5]);

        state[3] ^= state[4];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_7_3);
        state[4] =  modulo_2_64::minus(state[4],state[3]);


        state[1] ^= state[4];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_6_0);
        state[4] =  modulo_2_64::minus(state[4],state[1]);

        state[3] ^= state[6];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_6_1);
        state[6] =  modulo_2_64::minus(state[6],state[3]);

        state[5] ^= state[0];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_6_2);
        state[0] =  modulo_2_64::minus(state[0],state[5]);

        state[7] ^= state[2];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_6_3);
        state[2] =  modulo_2_64::minus(state[2],state[7]);


        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_5_0);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[7] ^= state[4];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_5_1);
        state[4] =  modulo_2_64::minus(state[4],state[7]);

        state[5] ^= state[6];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_5_2);
        state[6] =  modulo_2_64::minus(state[6],state[5]);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_5_3);
        state[0] =  modulo_2_64::minus(state[0],state[3]);


        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_4_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_4_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[5] ^= state[4];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_4_2);
        state[4] =  modulo_2_64::minus(state[4],state[5]);

        state[7] ^= state[6];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_4_3);
        state[6] =  modulo_2_64::minus(state[6],state[7]);

        for i in 0..constants::WORD_COUNT_0512 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_0512+1)]);
        }
        state[constants::WORD_COUNT_0512-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        3],tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_0512-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        2],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_0512-1] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-
        1],(2*r+1) as u64);


        state[1] ^= state[6];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_3_0);
        state[6] =  modulo_2_64::minus(state[6],state[1]);

        state[7] ^= state[0];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_3_1);
        state[0] =  modulo_2_64::minus(state[0],state[7]);

        state[5] ^= state[2];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_3_2);
        state[2] =  modulo_2_64::minus(state[2],state[5]);

        state[3] ^= state[4];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_3_3);
        state[4] =  modulo_2_64::minus(state[4],state[3]);


        state[1] ^= state[4];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_2_0);
        state[4] =  modulo_2_64::minus(state[4],state[1]);

        state[3] ^= state[6];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_2_1);
        state[6] =  modulo_2_64::minus(state[6],state[3]);

        state[5] ^= state[0];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_2_2);
        state[0] =  modulo_2_64::minus(state[0],state[5]);

        state[7] ^= state[2];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_2_3);
        state[2] =  modulo_2_64::minus(state[2],state[7]);


        state[1] ^= state[2];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_1_0);
        state[2] =  modulo_2_64::minus(state[2],state[1]);

        state[7] ^= state[4];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_1_1);
        state[4] =  modulo_2_64::minus(state[4],state[7]);

        state[5] ^= state[6];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_1_2);
        state[6] =  modulo_2_64::minus(state[6],state[5]);

        state[3] ^= state[0];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_1_3);
        state[0] =  modulo_2_64::minus(state[0],state[3]);


        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_0512_0_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_0512_0_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[5] ^= state[4];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_0512_0_2);
        state[4] =  modulo_2_64::minus(state[4],state[5]);

        state[7] ^= state[6];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_0512_0_3);
        state[6] =  modulo_2_64::minus(state[6],state[7]);

    }
    //first key injection
    for i in 0..constants::WORD_COUNT_0512 {
        state[i] = modulo_2_64::minus(state[i],key[(i)%(constants::WORD_COUNT_0512+1)]);
    }
    state[constants::WORD_COUNT_0512-3] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-3],
    tweak[0]);
    state[constants::WORD_COUNT_0512-2] = modulo_2_64::minus(state[constants::WORD_COUNT_0512-2],
    tweak[1]);

}

/***************************************************************************************************
** FUNCTION NAME:  encrypt_block_1024
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn encrypt_block_1024(state : &mut [u64;16], key : &mut [u64;17], tweak : & [u64;3]){


//get parity
    key[constants::WORD_COUNT_1024] = constants::C_240;
    for i in 0..constants::WORD_COUNT_1024{
        key[constants::WORD_COUNT_1024] ^= key[i];
    }

//first key injection
    for i in 0..constants::WORD_COUNT_1024 {
        state[i] = modulo_2_64::add(state[i],key[(i)%(constants::WORD_COUNT_1024+1)]);
    }
    state[constants::WORD_COUNT_1024-3] = modulo_2_64::add(state[constants::WORD_COUNT_1024-3],
    tweak[0]);
    state[constants::WORD_COUNT_1024-2] = modulo_2_64::add(state[constants::WORD_COUNT_1024-2],
    tweak[1]);

//process rounds
    for r in 0..constants::ROUNDS_1024{


        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_0_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_0_1);
        state[3] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_0_2);
        state[5] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_0_3);
        state[7] ^= state[6];

        state[8] =  modulo_2_64::add(state[8],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_0_4);
        state[9] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_0_5);
        state[11] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_0_6);
        state[13] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_0_7);
        state[15] ^= state[14];

        state[0] =  modulo_2_64::add(state[0],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_1_0);
        state[9] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_1_1);
        state[13] ^= state[2];

        state[6] =  modulo_2_64::add(state[6],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_1_2);
        state[11] ^= state[6];

        state[4] =  modulo_2_64::add(state[4],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_1_3);
        state[15] ^= state[4];

        state[10] =  modulo_2_64::add(state[10],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_1_4);
        state[7] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_1_5);
        state[3] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_1_6);
        state[5] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_1_7);
        state[1] ^= state[8];

        state[0] =  modulo_2_64::add(state[0],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_2_0);
        state[7] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_2_1);
        state[5] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_2_2);
        state[3] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_2_3);
        state[1] ^= state[6];

        state[12] =  modulo_2_64::add(state[12],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_2_4);
        state[15] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_2_5);
        state[13] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_2_6);
        state[11] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_2_7);
        state[9] ^= state[10];

        state[0] =  modulo_2_64::add(state[0],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_3_0);
        state[15] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_3_1);
        state[11] ^= state[2];

        state[6] =  modulo_2_64::add(state[6],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_3_2);
        state[13] ^= state[6];

        state[4] =  modulo_2_64::add(state[4],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_3_3);
        state[9] ^= state[4];

        state[14] =  modulo_2_64::add(state[14],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_3_4);
        state[1] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_3_5);
        state[5] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_3_6);
        state[3] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_3_7);
        state[7] ^= state[12];

        for i in 0..constants::WORD_COUNT_1024 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_1024+1)]);
        }
        state[constants::WORD_COUNT_1024-3] = modulo_2_64::add(state[constants::WORD_COUNT_1024-3],
        tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_1024-2] = modulo_2_64::add(state[constants::WORD_COUNT_1024-2],
        tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_1024-1] = modulo_2_64::add(state[constants::WORD_COUNT_1024-1],
        (2*r+1) as u64);

        state[0] =  modulo_2_64::add(state[0],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_4_0);
        state[1] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_4_1);
        state[3] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_4_2);
        state[5] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_4_3);
        state[7] ^= state[6];

        state[8] =  modulo_2_64::add(state[8],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_4_4);
        state[9] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_4_5);
        state[11] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_4_6);
        state[13] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_4_7);
        state[15] ^= state[14];

        state[0] =  modulo_2_64::add(state[0],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_5_0);
        state[9] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_5_1);
        state[13] ^= state[2];

        state[6] =  modulo_2_64::add(state[6],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_5_2);
        state[11] ^= state[6];

        state[4] =  modulo_2_64::add(state[4],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_5_3);
        state[15] ^= state[4];

        state[10] =  modulo_2_64::add(state[10],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_5_4);
        state[7] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_5_5);
        state[3] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_5_6);
        state[5] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_5_7);
        state[1] ^= state[8];

        state[0] =  modulo_2_64::add(state[0],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_6_0);
        state[7] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_6_1);
        state[5] ^= state[2];

        state[4] =  modulo_2_64::add(state[4],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_6_2);
        state[3] ^= state[4];

        state[6] =  modulo_2_64::add(state[6],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_6_3);
        state[1] ^= state[6];

        state[12] =  modulo_2_64::add(state[12],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_6_4);
        state[15] ^= state[12];

        state[14] =  modulo_2_64::add(state[14],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_6_5);
        state[13] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_6_6);
        state[11] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_6_7);
        state[9] ^= state[10];

        state[0] =  modulo_2_64::add(state[0],state[15]);
        state[15] = rotate_64_left(state[15], constants::ROTATE_CONSTANTS_1024_7_0);
        state[15] ^= state[0];

        state[2] =  modulo_2_64::add(state[2],state[11]);
        state[11] = rotate_64_left(state[11], constants::ROTATE_CONSTANTS_1024_7_1);
        state[11] ^= state[2];

        state[6] =  modulo_2_64::add(state[6],state[13]);
        state[13] = rotate_64_left(state[13], constants::ROTATE_CONSTANTS_1024_7_2);
        state[13] ^= state[6];

        state[4] =  modulo_2_64::add(state[4],state[9]);
        state[9] = rotate_64_left(state[9], constants::ROTATE_CONSTANTS_1024_7_3);
        state[9] ^= state[4];

        state[14] =  modulo_2_64::add(state[14],state[1]);
        state[1] = rotate_64_left(state[1], constants::ROTATE_CONSTANTS_1024_7_4);
        state[1] ^= state[14];

        state[8] =  modulo_2_64::add(state[8],state[5]);
        state[5] = rotate_64_left(state[5], constants::ROTATE_CONSTANTS_1024_7_5);
        state[5] ^= state[8];

        state[10] =  modulo_2_64::add(state[10],state[3]);
        state[3] = rotate_64_left(state[3], constants::ROTATE_CONSTANTS_1024_7_6);
        state[3] ^= state[10];

        state[12] =  modulo_2_64::add(state[12],state[7]);
        state[7] = rotate_64_left(state[7], constants::ROTATE_CONSTANTS_1024_7_7);
        state[7] ^= state[12];

        for i in 0..constants::WORD_COUNT_1024 {
            state[i] = modulo_2_64::add(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_1024+1)]);
        }
        state[constants::WORD_COUNT_1024-3] = modulo_2_64::add(state[constants::WORD_COUNT_1024-3],
        tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_1024-2] = modulo_2_64::add(state[constants::WORD_COUNT_1024-2],
        tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_1024-1] = modulo_2_64::add(state[constants::WORD_COUNT_1024-1],
        (2*r+2) as u64);

    }
}

/***************************************************************************************************
** FUNCTION NAME:  decrypt_block_1024
**
** PURPOSE:        scrambles the state
**
** ARGUMENTS:      state = the block being operated on
**                 key = the key used to scramble the state
**                 tweak = a modifier structure used specifically in threefish
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
pub fn decrypt_block_1024(state : &mut [u64;16], key : &mut [u64;17], tweak : &
[u64;3]){

//get parity
    key[constants::WORD_COUNT_1024] = constants::C_240;
    for i in 0..constants::WORD_COUNT_1024{
        key[constants::WORD_COUNT_1024] ^= key[i];
    }

//process rounds
    for r in (0..constants::ROUNDS_1024).rev(){

        for i in 0..constants::WORD_COUNT_1024 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+2)%(constants::WORD_COUNT_1024+1)]);
        }
        state[constants::WORD_COUNT_1024-3] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        3],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_1024-2] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        2],tweak[(2*r+3)%3]);
        state[constants::WORD_COUNT_1024-1] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        1],(2*r+2) as u64);


        state[15] ^= state[0];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_7_0);
        state[0] =  modulo_2_64::minus(state[0],state[15]);

        state[11] ^= state[2];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_7_1);
        state[2] =  modulo_2_64::minus(state[2],state[11]);

        state[13] ^= state[6];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_7_2);
        state[6] =  modulo_2_64::minus(state[6],state[13]);

        state[9] ^= state[4];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_7_3);
        state[4] =  modulo_2_64::minus(state[4],state[9]);

        state[1] ^= state[14];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_7_4);
        state[14] =  modulo_2_64::minus(state[14],state[1]);

        state[5] ^= state[8];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_7_5);
        state[8] =  modulo_2_64::minus(state[8],state[5]);

        state[3] ^= state[10];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_7_6);
        state[10] =  modulo_2_64::minus(state[10],state[3]);

        state[7] ^= state[12];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_7_7);
        state[12] =  modulo_2_64::minus(state[12],state[7]);


        state[7] ^= state[0];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_6_0);
        state[0] =  modulo_2_64::minus(state[0],state[7]);

        state[5] ^= state[2];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_6_1);
        state[2] =  modulo_2_64::minus(state[2],state[5]);

        state[3] ^= state[4];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_6_2);
        state[4] =  modulo_2_64::minus(state[4],state[3]);

        state[1] ^= state[6];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_6_3);
        state[6] =  modulo_2_64::minus(state[6],state[1]);

        state[15] ^= state[12];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_6_4);
        state[12] =  modulo_2_64::minus(state[12],state[15]);

        state[13] ^= state[14];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_6_5);
        state[14] =  modulo_2_64::minus(state[14],state[13]);

        state[11] ^= state[8];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_6_6);
        state[8] =  modulo_2_64::minus(state[8],state[11]);

        state[9] ^= state[10];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_6_7);
        state[10] =  modulo_2_64::minus(state[10],state[9]);


        state[9] ^= state[0];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_5_0);
        state[0] =  modulo_2_64::minus(state[0],state[9]);

        state[13] ^= state[2];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_5_1);
        state[2] =  modulo_2_64::minus(state[2],state[13]);

        state[11] ^= state[6];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_5_2);
        state[6] =  modulo_2_64::minus(state[6],state[11]);

        state[15] ^= state[4];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_5_3);
        state[4] =  modulo_2_64::minus(state[4],state[15]);

        state[7] ^= state[10];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_5_4);
        state[10] =  modulo_2_64::minus(state[10],state[7]);

        state[3] ^= state[12];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_5_5);
        state[12] =  modulo_2_64::minus(state[12],state[3]);

        state[5] ^= state[14];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_5_6);
        state[14] =  modulo_2_64::minus(state[14],state[5]);

        state[1] ^= state[8];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_5_7);
        state[8] =  modulo_2_64::minus(state[8],state[1]);


        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_4_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_4_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[5] ^= state[4];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_4_2);
        state[4] =  modulo_2_64::minus(state[4],state[5]);

        state[7] ^= state[6];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_4_3);
        state[6] =  modulo_2_64::minus(state[6],state[7]);

        state[9] ^= state[8];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_4_4);
        state[8] =  modulo_2_64::minus(state[8],state[9]);

        state[11] ^= state[10];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_4_5);
        state[10] =  modulo_2_64::minus(state[10],state[11]);

        state[13] ^= state[12];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_4_6);
        state[12] =  modulo_2_64::minus(state[12],state[13]);

        state[15] ^= state[14];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_4_7);
        state[14] =  modulo_2_64::minus(state[14],state[15]);

        for i in 0..constants::WORD_COUNT_1024 {
            state[i] = modulo_2_64::minus(state[i],key[(2*r+i+1)%(constants::WORD_COUNT_1024+1)]);
        }
        state[constants::WORD_COUNT_1024-3] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        3],tweak[(2*r+1)%3]);
        state[constants::WORD_COUNT_1024-2] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        2],tweak[(2*r+2)%3]);
        state[constants::WORD_COUNT_1024-1] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-
        1],(2*r+1) as u64);


        state[15] ^= state[0];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_3_0);
        state[0] =  modulo_2_64::minus(state[0],state[15]);

        state[11] ^= state[2];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_3_1);
        state[2] =  modulo_2_64::minus(state[2],state[11]);

        state[13] ^= state[6];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_3_2);
        state[6] =  modulo_2_64::minus(state[6],state[13]);

        state[9] ^= state[4];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_3_3);
        state[4] =  modulo_2_64::minus(state[4],state[9]);

        state[1] ^= state[14];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_3_4);
        state[14] =  modulo_2_64::minus(state[14],state[1]);

        state[5] ^= state[8];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_3_5);
        state[8] =  modulo_2_64::minus(state[8],state[5]);

        state[3] ^= state[10];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_3_6);
        state[10] =  modulo_2_64::minus(state[10],state[3]);

        state[7] ^= state[12];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_3_7);
        state[12] =  modulo_2_64::minus(state[12],state[7]);


        state[7] ^= state[0];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_2_0);
        state[0] =  modulo_2_64::minus(state[0],state[7]);

        state[5] ^= state[2];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_2_1);
        state[2] =  modulo_2_64::minus(state[2],state[5]);

        state[3] ^= state[4];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_2_2);
        state[4] =  modulo_2_64::minus(state[4],state[3]);

        state[1] ^= state[6];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_2_3);
        state[6] =  modulo_2_64::minus(state[6],state[1]);

        state[15] ^= state[12];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_2_4);
        state[12] =  modulo_2_64::minus(state[12],state[15]);

        state[13] ^= state[14];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_2_5);
        state[14] =  modulo_2_64::minus(state[14],state[13]);

        state[11] ^= state[8];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_2_6);
        state[8] =  modulo_2_64::minus(state[8],state[11]);

        state[9] ^= state[10];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_2_7);
        state[10] =  modulo_2_64::minus(state[10],state[9]);


        state[9] ^= state[0];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_1_0);
        state[0] =  modulo_2_64::minus(state[0],state[9]);

        state[13] ^= state[2];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_1_1);
        state[2] =  modulo_2_64::minus(state[2],state[13]);

        state[11] ^= state[6];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_1_2);
        state[6] =  modulo_2_64::minus(state[6],state[11]);

        state[15] ^= state[4];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_1_3);
        state[4] =  modulo_2_64::minus(state[4],state[15]);

        state[7] ^= state[10];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_1_4);
        state[10] =  modulo_2_64::minus(state[10],state[7]);

        state[3] ^= state[12];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_1_5);
        state[12] =  modulo_2_64::minus(state[12],state[3]);

        state[5] ^= state[14];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_1_6);
        state[14] =  modulo_2_64::minus(state[14],state[5]);

        state[1] ^= state[8];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_1_7);
        state[8] =  modulo_2_64::minus(state[8],state[1]);


        state[1] ^= state[0];
        state[1] = rotate_64_right(state[1], constants::ROTATE_CONSTANTS_1024_0_0);
        state[0] =  modulo_2_64::minus(state[0],state[1]);

        state[3] ^= state[2];
        state[3] = rotate_64_right(state[3], constants::ROTATE_CONSTANTS_1024_0_1);
        state[2] =  modulo_2_64::minus(state[2],state[3]);

        state[5] ^= state[4];
        state[5] = rotate_64_right(state[5], constants::ROTATE_CONSTANTS_1024_0_2);
        state[4] =  modulo_2_64::minus(state[4],state[5]);

        state[7] ^= state[6];
        state[7] = rotate_64_right(state[7], constants::ROTATE_CONSTANTS_1024_0_3);
        state[6] =  modulo_2_64::minus(state[6],state[7]);

        state[9] ^= state[8];
        state[9] = rotate_64_right(state[9], constants::ROTATE_CONSTANTS_1024_0_4);
        state[8] =  modulo_2_64::minus(state[8],state[9]);

        state[11] ^= state[10];
        state[11] = rotate_64_right(state[11], constants::ROTATE_CONSTANTS_1024_0_5);
        state[10] =  modulo_2_64::minus(state[10],state[11]);

        state[13] ^= state[12];
        state[13] = rotate_64_right(state[13], constants::ROTATE_CONSTANTS_1024_0_6);
        state[12] =  modulo_2_64::minus(state[12],state[13]);

        state[15] ^= state[14];
        state[15] = rotate_64_right(state[15], constants::ROTATE_CONSTANTS_1024_0_7);
        state[14] =  modulo_2_64::minus(state[14],state[15]);
    }

//first key injection
    for i in 0..constants::WORD_COUNT_1024 {
        state[i] = modulo_2_64::minus(state[i],key[(i)%(constants::WORD_COUNT_1024+1)]);
    }
    state[constants::WORD_COUNT_1024-3] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-3],
    tweak[0]);
    state[constants::WORD_COUNT_1024-2] = modulo_2_64::minus(state[constants::WORD_COUNT_1024-2],
    tweak[1]);

}
