extern crate threefish;

const EXPECTED_RESULTS_0256 : [u64;4] = [
    0x94EEEA8B1F2ADA84, 0xADF103313EAE6670, 0x952419A1F4B16D53, 0xD83F13E63C9F6B11];

const EXPECTED_RESULTS_0512 : [u64;8] = [
    0xBC2560EFC6BBA2B1, 0xE3361F162238EB40, 0xFB8631EE0ABBD175, 0x7B9479D4C5479ED1,
    0xCFF0356E58F8C27B, 0xB1B7B08430F0E7F7, 0xE9A380A56139ABF1, 0xBE7B6D4AA11EB47E];

const EXPECTED_RESULTS_1024 : [u64;16]= [
    0x04B3053D0A3D5CF0, 0x0136E0D1C7DD85F7, 0x067B212F6EA78A5C, 0x0DA9C10B4C54E1C6,
    0x0F4EC27394CBACF0, 0x32437F0568EA4FD5, 0xCFF56D1D7654B49C, 0xA2D5FB14369B2E7B,
    0x540306B460472E0B, 0x71C18254BCEA820D, 0xC36B4068BEAF32C8, 0xFA4329597A360095,
    0xC4A36C28434A5B9A, 0xD54331444B1046CF, 0xDF11834830B2A460, 0x1E39E8DFE1F7EE4F];

fn print(a : *const u64, b : *const u64, word_count : usize){
    unsafe{
        println!("expected: ");
        for i in 0..word_count{
            print!("{:016x} ", *((a as u64 + (8*i)as u64)as *const u64));
        }
        //println!("\nbut got this instead: ");
        println!("\n");
        for i in 0..word_count{
            print!("{:016x} ", *((b as u64 + (8*i)as u64)as *const u64));
        }
        println!();
    }
}

/***************************************************************************************************
** FUNCTION NAME:  compare_blocks
**
** PURPOSE:        compares two blocks to see if they are the same
**
** ARGUMENTS:      a = the first block
**                 b = the second block
**                 word_count = the number of words to compare in the blocks
**
** RETURN:         true = the blocks are the same
**                 false = the blocks are different
**
** NOTES:          (none)
***************************************************************************************************/
fn compare_blocks(a : *const u64, b : *const u64, word_count : usize) -> bool{
    unsafe {
        for i in 0..word_count{
            if *(((a as u64) + (i*8)as u64)as *const u64) !=
            *(((b as u64) + (i*8)as u64)as *const u64){
                print(a,b,word_count);
                return false;
            }
        }
        return true;
    }
}

#[test]
/***************************************************************************************************
** TEST NAME:      test_block_operations
**
** PURPOSE:        test that the overall algorithm encrypts and decrypts correctly
**
** ARGUMENTS:      (none)
**
** RETURN:         void
**
** NOTES:          (none)
***************************************************************************************************/
fn test_block_operations(){

    let mut test_result : bool;
    let tweak : [u64;3] = [0;3];

    let mut key_0256 : [u64;5] = [0;5];
    let original_block_0256 : [u64;4] = [0;4];
    let mut block_0256 : [u64;4] = [0;4];
    threefish::encrypt_block_0256(&mut block_0256, &mut key_0256, &tweak);
    test_result = compare_blocks(&EXPECTED_RESULTS_0256[0], &block_0256[0],4);
    assert_eq!(test_result,true);
    threefish::decrypt_block_0256(&mut block_0256, &mut key_0256, &tweak);
    test_result = compare_blocks(&original_block_0256[0], &block_0256[0],4);
    assert_eq!(test_result,true);

    let mut key_0512 : [u64;9] = [0;9];
    let original_block_0512 : [u64;8] = [0;8];
    let mut block_0512 : [u64;8] = [0;8];
    threefish::encrypt_block_0512(&mut block_0512, &mut key_0512, &tweak);
    test_result = compare_blocks(&EXPECTED_RESULTS_0512[0], &block_0512[0],8);
    assert_eq!(test_result,true);
    threefish::decrypt_block_0512(&mut block_0512, &mut key_0512, &tweak);
    test_result = compare_blocks(&original_block_0512[0], &block_0512[0],8);
    assert_eq!(test_result,true);

    let mut key_1024 : [u64;17] = [0;17];
    let original_block_1024 : [u64;16] = [0;16];
    let mut block_1024 : [u64;16] = [0;16];
    threefish::encrypt_block_1024(&mut block_1024, &mut key_1024, &tweak);
    test_result = compare_blocks(&EXPECTED_RESULTS_1024[0], &block_1024[0],16);
    assert_eq!(test_result,true);
    threefish::decrypt_block_1024(&mut block_1024, &mut key_1024, &tweak);
    test_result = compare_blocks(&original_block_1024[0], &block_1024[0],16);
    assert_eq!(test_result,true);
}
